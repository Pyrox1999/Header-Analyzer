This app prints you of a page:
Content-Security-Policy, Strict-Transport-Security, X-Frame-Options, X-Content-Type-Options, Referrer-Policy and Permissions-Policy.
Use it only when you have the legal permisson to do it!

Music by Eric Matyas